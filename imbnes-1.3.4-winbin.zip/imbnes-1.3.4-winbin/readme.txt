imbNES 1.3.4 Windows binary archive
-------

To generate a CD image with the It Might be NES (imbNES) emulator and games, 
run rombank.exe
The program allows you to load the ROM images you desire and to generate a CD
image, all by using a graphical user interface.
The program is intuitive and user-friendly, and as such, does not require documentation.
Unfortunately the program has no source code available; it was taken as it is from the
imbNES 1.3.2 distribution. Source code was probably lost, and thus a rewrite is needed.

For information and news about It Might Be Nes, visit the page at
http://unhaut.fav.cc/imbnes

If you have comments or questions email them to: tails92@gmail.com
